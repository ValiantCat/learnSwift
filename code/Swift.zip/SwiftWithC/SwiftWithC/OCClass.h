//
//  OCClass.h
//  SwiftWithC
//
//  Created by nero on 16/1/16.
//  Copyright © 2016年 nero. All rights reserved.
//

#import <Foundation/Foundation.h>
typedef NS_ENUM(NSInteger, CEnumStyle) {
    CEnumStyleDefault,
    CEnumStyleValue1,
    CEnumStyleValue2,
    CEnumStyleSubtitle
};
@interface OCClass : NSObject

@end
