//
//  OCClass.m
//  SwiftWithC
//
//  Created by nero on 16/1/16.
//  Copyright © 2016年 nero. All rights reserved.
//

#import "OCClass.h"

@implementation OCClass

@end
